// api_service.dart - Backend API, State Management and Transaction Service Layer

import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../models/models.dart';

class ApiService {
  // Singleton pattern
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal() {
    _seedInitialData();
  }

  // Active session
  UserModel? currentUser;

  // In-Memory Database Store (Emulating Supabase PostgreSQL with ACID constraints)
  final List<UserModel> _users = [];
  final List<ItemModel> _items = [];
  final List<TransactionModel> _transactions = [];
  final List<Map<String, dynamic>> _auditLogs = [];
  final Map<String, String> _pendingOtps = {}; // email -> otp

  // Domain whitelist for South African higher education
  final List<String> _domainWhitelist = [
    'eduvos.com',
    'student.eduvos.com',
    'student.uj.ac.za',
    'students.wits.ac.za',
    'myuct.ac.za',
    'student.ukzn.ac.za',
    'ufs4life.ac.za',
  ];

  // Seed sample initial data for testing and demonstrations
  void _seedInitialData() {
    // 1. Seed Sample Users
    final sampleDonor = UserModel(
      id: 'usr-donor-001',
      campusId: 'campus-bedfordview',
      campusName: 'Eduvos - Bedfordview',
      fullName: 'Zachariah Ebrahim',
      email: 'zach@student.eduvos.com',
      studentNumber: 'EDU-2024-8841',
      creditBalance: 35,
      isVerified: true,
      role: 'ROLE_STUDENT',
    );

    final sampleReceiver = UserModel(
      id: 'usr-receiver-002',
      campusId: 'campus-bedfordview',
      campusName: 'Eduvos - Bedfordview',
      fullName: 'Mbalenhle Rampedi',
      email: 'mbalenhle@student.eduvos.com',
      studentNumber: 'EDU-2025-1049',
      creditBalance: 25,
      isVerified: true,
      role: 'ROLE_STUDENT',
    );

    final sampleModerator = UserModel(
      id: 'usr-mod-003',
      campusId: 'campus-bedfordview',
      campusName: 'Eduvos - Bedfordview',
      fullName: 'Campus Admin (Moderator)',
      email: 'moderator@eduvos.com',
      studentNumber: 'EMP-MOD-01',
      creditBalance: 100,
      isVerified: true,
      role: 'ROLE_MODERATOR',
    );

    _users.addAll([sampleDonor, sampleReceiver, sampleModerator]);

    // 2. Seed Sample Item Listings
    _items.addAll([
      ItemModel(
        id: 'item-001',
        listedByUserId: sampleDonor.id,
        donorName: sampleDonor.fullName,
        campusId: 'campus-bedfordview',
        category: 'Textbooks',
        title: 'Information Systems 2A Prescribed Book',
        description: 'Hardcover textbook for ITDMA3 module. Clean pages with minor pencil notes in Chapter 3.',
        condition: 'Good',
        creditCost: 15,
        status: ItemStatus.available,
        photoUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
      ),
      ItemModel(
        id: 'item-002',
        listedByUserId: sampleDonor.id,
        donorName: sampleDonor.fullName,
        campusId: 'campus-bedfordview',
        category: 'Stationery',
        title: 'Casio Scientific Calculator FX-82ZA Plus II',
        description: 'South African curriculum approved calculator with protective cover. Perfect condition.',
        condition: 'Like New',
        creditCost: 20,
        status: ItemStatus.available,
        photoUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=400',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
      ),
      ItemModel(
        id: 'item-003',
        listedByUserId: sampleDonor.id,
        donorName: sampleDonor.fullName,
        campusId: 'campus-bedfordview',
        category: 'Food/Meals',
        title: 'Campus Cafeteria Lunch Vouchers (Pack of 5)',
        description: 'Unused meal vouchers valid at Bedfordview Cafeteria until end of semester.',
        condition: 'Brand New',
        creditCost: 10,
        status: ItemStatus.available,
        photoUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400',
        createdAt: DateTime.now().subtract(const Duration(hours: 12)),
      ),
      ItemModel(
        id: 'item-004',
        listedByUserId: sampleDonor.id,
        donorName: sampleDonor.fullName,
        campusId: 'campus-bedfordview',
        category: 'Clothing',
        title: 'Eduvos Branded Navy Fleece Jacket (Size M)',
        description: 'Warm campus winter fleece. Washed and in great condition.',
        condition: 'Good',
        creditCost: 15,
        status: ItemStatus.available,
        photoUrl: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400',
        createdAt: DateTime.now().subtract(const Duration(hours: 5)),
      ),
    ]);

    // Default active user is the sample receiver
    currentUser = sampleReceiver;
  }

  // ==========================================
  // 1. AUTHENTICATION & VERIFICATION MODULE
  // ==========================================

  bool validateEmailDomain(String email) {
    if (!email.contains('@')) return false;
    final domain = email.split('@').last.toLowerCase().trim();
    return _domainWhitelist.contains(domain);
  }

  Future<Map<String, dynamic>> requestRegistrationOtp(String email) async {
    await Future.delayed(const Duration(milliseconds: 600)); // Simulated network latency
    if (!validateEmailDomain(email)) {
      return {
        'success': false,
        'message': 'Registration restricted to accredited university student email domains (@eduvos.com, @student.uj.ac.za, etc.).'
      };
    }
    // Generate 6-digit OTP
    final otp = '849201'; // deterministic for demo/testing
    _pendingOtps[email.toLowerCase().trim()] = otp;
    return {
      'success': true,
      'message': 'Verification code sent to $email. (Demo OTP: 849201)',
      'otp': otp
    };
  }

  Future<Map<String, dynamic>> completeRegistration({
    required String fullName,
    required String email,
    required String studentNumber,
    required String campusName,
    required String password,
    required String enteredOtp,
  }) async {
    await Future.delayed(const Duration(milliseconds: 600));
    final normalizedEmail = email.toLowerCase().trim();

    if (_pendingOtps[normalizedEmail] != enteredOtp) {
      return {'success': false, 'message': 'Invalid or expired OTP verification code.'};
    }

    final newUser = UserModel(
      id: 'usr-${DateTime.now().millisecondsSinceEpoch}',
      campusId: 'campus-bedfordview',
      campusName: campusName,
      fullName: fullName,
      email: normalizedEmail,
      studentNumber: studentNumber,
      creditBalance: 10, // 10 starter credits
      isVerified: true,
      role: 'ROLE_STUDENT',
    );

    _users.add(newUser);
    currentUser = newUser;
    _pendingOtps.remove(normalizedEmail);

    _logAudit(newUser.id, 'ACCOUNT_REGISTERED', {'starter_credits': 10});

    return {
      'success': true,
      'message': 'Account verified! Welcome to SharAmigo. +10 Starter Credits added to your wallet.',
      'user': newUser
    };
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final normalizedEmail = email.toLowerCase().trim();
    final user = _users.firstWhere(
      (u) => u.email == normalizedEmail,
      orElse: () => UserModel(
        id: '',
        campusId: '',
        campusName: '',
        fullName: '',
        email: '',
        studentNumber: '',
        creditBalance: 0,
        isVerified: false,
      ),
    );

    if (user.id.isEmpty) {
      return {'success': false, 'message': 'Invalid student credentials or unregistered domain.'};
    }

    currentUser = user;
    _logAudit(user.id, 'USER_LOGIN', {'timestamp': DateTime.now().toIso8601String()});

    return {'success': true, 'message': 'Login successful.', 'user': user};
  }

  void switchUser(String userId) {
    currentUser = _users.firstWhere((u) => u.id == userId, orElse: () => _users.first);
  }

  // ==========================================
  // 2. ITEM CATALOG & DISCOVERY MODULE (CRUD)
  // ==========================================

  List<ItemModel> getActiveListings({String? category, String? query}) {
    return _items.where((item) {
      if (item.status != ItemStatus.available) return false;
      if (category != null && category != 'All' && item.category != category) return false;
      if (query != null && query.trim().isNotEmpty) {
        final q = query.toLowerCase().trim();
        final matchTitle = item.title.toLowerCase().contains(q);
        final matchDesc = item.description.toLowerCase().contains(q);
        if (!matchTitle && !matchDesc) return false;
      }
      return true;
    }).toList();
  }

  Future<Map<String, dynamic>> createListing({
    required String title,
    required String category,
    required String description,
    required String condition,
    required int creditCost,
    String? photoUrl,
  }) async {
    await Future.delayed(const Duration(milliseconds: 600));

    if (currentUser == null) {
      return {'success': false, 'message': 'Unauthorized. Please login.'};
    }

    final newItem = ItemModel(
      id: 'item-${DateTime.now().millisecondsSinceEpoch}',
      listedByUserId: currentUser!.id,
      donorName: currentUser!.fullName,
      campusId: currentUser!.campusId,
      category: category,
      title: title,
      description: description,
      condition: condition,
      creditCost: creditCost,
      status: ItemStatus.available,
      photoUrl: photoUrl ?? 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
      createdAt: DateTime.now(),
    );

    _items.insert(0, newItem);
    _logAudit(currentUser!.id, 'ITEM_CREATED', {'item_id': newItem.id, 'credit_cost': creditCost});

    return {'success': true, 'message': 'Resource published to campus feed!', 'item': newItem};
  }

  Future<Map<String, dynamic>> deleteListing(String itemId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final index = _items.indexWhere((i) => i.id == itemId);
    if (index == -1) return {'success': false, 'message': 'Item not found.'};

    _items[index].status = ItemStatus.deleted;
    _logAudit(currentUser?.id ?? 'SYS', 'ITEM_DELETED', {'item_id': itemId});

    return {'success': true, 'message': 'Listing successfully removed.'};
  }

  // ==========================================
  // 3. TRADE-IN & ESCROW TRANSACTION MODULE
  // ==========================================

  Future<Map<String, dynamic>> claimItem(String itemId) async {
    await Future.delayed(const Duration(milliseconds: 700));

    if (currentUser == null) {
      return {'success': false, 'message': 'Please login to claim resources.'};
    }

    final item = _items.firstWhere((i) => i.id == itemId);
    if (item.status != ItemStatus.available) {
      return {'success': false, 'message': 'Item has already been claimed by another student.'};
    }

    if (item.listedByUserId == currentUser!.id) {
      return {'success': false, 'message': 'You cannot claim your own listed item.'};
    }

    // Balance check
    if (currentUser!.creditBalance < item.creditCost) {
      return {
        'success': false,
        'message': 'Insufficient AmigoCredits! You have ${currentUser!.creditBalance} pts, but this item costs ${item.creditCost} pts. Trade in an item to earn credits!'
      };
    }

    // Atomic Escrow Hold Simulation
    currentUser!.creditBalance -= item.creditCost;
    item.status = ItemStatus.escrow;

    // Generate cryptographic QR verification hash
    final rawString = '${item.id}-${currentUser!.id}-${DateTime.now().millisecondsSinceEpoch}';
    final qrHash = md5.convert(utf8.encode(rawString)).toString();
    final pinFallback = '849201';

    final donor = _users.firstWhere((u) => u.id == item.listedByUserId);

    final txn = TransactionModel(
      id: 'txn-${DateTime.now().millisecondsSinceEpoch}',
      itemId: item.id,
      itemTitle: item.title,
      donorId: item.listedByUserId,
      donorName: donor.fullName,
      receiverId: currentUser!.id,
      receiverName: currentUser!.fullName,
      creditAmount: item.creditCost,
      status: TransactionStatus.pending,
      qrVerifyHash: qrHash,
      pinFallback: pinFallback,
      createdAt: DateTime.now(),
    );

    _transactions.insert(0, txn);

    _logAudit(currentUser!.id, 'ESCROW_CLAIM_INITIALIZED', {
      'transaction_id': txn.id,
      'credits_held': item.creditCost,
      'donor_id': donor.id
    });

    return {
      'success': true,
      'message': 'Item reserved! Credits placed in Escrow. Meet donor on campus to scan QR code.',
      'transaction': txn
    };
  }

  Future<Map<String, dynamic>> verifyAndCompleteHandover({
    required String transactionId,
    required String qrHashOrPin,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final index = _transactions.indexWhere((t) => t.id == transactionId && t.status == TransactionStatus.pending);
    if (index == -1) {
      return {'success': false, 'message': 'Invalid, expired, or already completed transaction.'};
    }

    final txn = _transactions[index];

    // Verify hash or PIN fallback
    if (txn.qrVerifyHash != qrHashOrPin && txn.pinFallback != qrHashOrPin) {
      return {'success': false, 'message': 'Invalid verification code. Scan must be performed from receiver ticket.'};
    }

    // Release Escrow & Credit the Donor
    final donor = _users.firstWhere((u) => u.id == txn.donorId);
    donor.creditBalance += txn.creditAmount;

    // Update States
    txn.status = TransactionStatus.completed;
    txn.completedAt = DateTime.now();

    final itemIndex = _items.indexWhere((i) => i.id == txn.itemId);
    if (itemIndex != -1) {
      _items[itemIndex].status = ItemStatus.exchanged;
    }

    _logAudit(donor.id, 'ESCROW_RELEASED_SUCCESS', {
      'transaction_id': txn.id,
      'credits_transferred': txn.creditAmount,
      'receiver_id': txn.receiverId
    });

    return {
      'success': true,
      'message': 'Exchange confirmed! +${txn.creditAmount} AmigoCredits released into your wallet.',
      'transaction': txn
    };
  }

  // ==========================================
  // 4. WALLET & AUDIT LEDGER MODULE
  // ==========================================

  List<TransactionModel> getUserTransactions(String userId) {
    return _transactions.where((t) => t.donorId == userId || t.receiverId == userId).toList();
  }

  int getEscrowHeldBalance(String userId) {
    return _transactions
        .where((t) => t.receiverId == userId && t.status == TransactionStatus.pending)
        .fold(0, (sum, t) => sum + t.creditAmount);
  }

  // ==========================================
  // 5. MODERATION & FLAGGING MODULE
  // ==========================================

  Future<Map<String, dynamic>> flagListing(String itemId, String reason) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final item = _items.firstWhere((i) => i.id == itemId);
    item.flagCount += 1;

    _logAudit(currentUser?.id ?? 'ANON', 'ITEM_FLAGGED', {'item_id': itemId, 'reason': reason});

    // Auto-safeguard: Hide if flagged 3 or more times
    if (item.flagCount >= 3) {
      item.status = ItemStatus.deleted;
    }

    return {'success': true, 'message': 'Listing reported to campus moderator.'};
  }

  List<ItemModel> getReportedItems() {
    return _items.where((i) => i.flagCount > 0).toList();
  }

  void _logAudit(String userId, String action, Map<String, dynamic> details) {
    _auditLogs.add({
      'timestamp': DateTime.now().toIso8601String(),
      'user_id': userId,
      'action': action,
      'details': details,
    });
  }
}
