// main.dart - SharAmigo Root Entry Point and Theme Configuration

import 'package:flutter/material.dart';
import 'screens/auth_screen.dart';
import 'screens/home_feed_screen.dart';
import 'services/api_service.dart';

void main() {
  runApp(const SharAmigoApp());
}

class SharAmigoApp extends StatefulWidget {
  const SharAmigoApp({Key? key}) : super(key: key);

  @override
  State<SharAmigoApp> createState() => _SharAmigoAppState();
}

class _SharAmigoAppState extends State<SharAmigoApp> {
  final _apiService = ApiService();
  bool _isAuthenticated = true; // Seeded default user active

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SharAmigo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF1E3A8A), // Campus Deep Navy
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E3A8A),
          primary: const Color(0xFF1E3A8A),
          secondary: const Color(0xFF0F766E), // Campus Teal
          tertiary: const Color(0xFF16A34A), // Emerald Balance
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E3A8A),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
      ),
      home: _isAuthenticated && _apiService.currentUser != null
          ? HomeFeedScreen(onLogout: () => setState(() => _isAuthenticated = false))
          : AuthScreen(onAuthSuccess: () => setState(() => _isAuthenticated = true)),
    );
  }
}
