// models.dart - Core Data Models for SharAmigo

class UserModel {
  final String id;
  final String campusId;
  final String campusName;
  final String fullName;
  final String email;
  final String studentNumber;
  int creditBalance;
  final bool isVerified;
  final String role; // 'ROLE_STUDENT' or 'ROLE_MODERATOR'

  UserModel({
    required this.id,
    required this.campusId,
    required this.campusName,
    required this.fullName,
    required this.email,
    required this.studentNumber,
    required this.creditBalance,
    required this.isVerified,
    this.role = 'ROLE_STUDENT',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'campusId': campusId,
        'campusName': campusName,
        'fullName': fullName,
        'email': email,
        'studentNumber': studentNumber,
        'creditBalance': creditBalance,
        'isVerified': isVerified,
        'role': role,
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'],
        campusId: json['campusId'],
        campusName: json['campusName'],
        fullName: json['fullName'],
        email: json['email'],
        studentNumber: json['studentNumber'],
        creditBalance: json['creditBalance'],
        isVerified: json['isVerified'] ?? true,
        role: json['role'] ?? 'ROLE_STUDENT',
      );
}

enum ItemStatus { available, escrow, exchanged, deleted }

class ItemModel {
  final String id;
  final String listedByUserId;
  final String donorName;
  final String campusId;
  final String category; // 'Textbooks', 'Food/Meals', 'Stationery', 'Clothing'
  final String title;
  final String description;
  final String condition;
  final int creditCost;
  ItemStatus status;
  final String photoUrl;
  int flagCount;
  final DateTime createdAt;

  ItemModel({
    required this.id,
    required this.listedByUserId,
    required this.donorName,
    required this.campusId,
    required this.category,
    required this.title,
    required this.description,
    required this.condition,
    required this.creditCost,
    this.status = ItemStatus.available,
    required this.photoUrl,
    this.flagCount = 0,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'listedByUserId': listedByUserId,
        'donorName': donorName,
        'campusId': campusId,
        'category': category,
        'title': title,
        'description': description,
        'condition': condition,
        'creditCost': creditCost,
        'status': status.name,
        'photoUrl': photoUrl,
        'flagCount': flagCount,
        'createdAt': createdAt.toIso8601String(),
      };
}

enum TransactionStatus { pending, completed, cancelled, disputed }

class TransactionModel {
  final String id;
  final String itemId;
  final String itemTitle;
  final String donorId;
  final String donorName;
  final String receiverId;
  final String receiverName;
  final int creditAmount;
  TransactionStatus status;
  final String qrVerifyHash;
  final String pinFallback;
  final DateTime createdAt;
  DateTime? completedAt;

  TransactionModel({
    required this.id,
    required this.itemId,
    required this.itemTitle,
    required this.donorId,
    required this.donorName,
    required this.receiverId,
    required this.receiverName,
    required this.creditAmount,
    this.status = TransactionStatus.pending,
    required this.qrVerifyHash,
    required this.pinFallback,
    required this.createdAt,
    this.completedAt,
  });
}
