// upload_listing_screen.dart - Trade-In Resource Upload Flow with Pricing Rules

import 'package:flutter/material.dart';
import '../services/api_service.dart';

class UploadListingScreen extends StatefulWidget {
  const UploadListingScreen({Key? key}) : super(key: key);

  @override
  State<UploadListingScreen> createState() => _UploadListingScreenState();
}

class _UploadListingScreenState extends State<UploadListingScreen> {
  final _apiService = ApiService();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  String _category = 'Textbooks';
  String _condition = 'Good';
  int _creditCost = 15;
  bool _isLoading = false;

  final Map<String, int> _categoryMaxLimits = {
    'Textbooks': 30,
    'Stationery': 20,
    'Food/Meals': 15,
    'Clothing': 20,
  };

  void _handleSubmit() async {
    if (_titleController.text.trim().isEmpty || _descriptionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in both title and description.')),
      );
      return;
    }

    setState(() => _isLoading = true);
    final res = await _apiService.createListing(
      title: _titleController.text.trim(),
      category: _category,
      description: _descriptionController.text.trim(),
      condition: _condition,
      creditCost: _creditCost,
    );
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trade-In a Resource'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Image Upload Placeholder
            Container(
              height: 140,
              decoration: BoxDecoration(
                color: const Color(0xFFF1F5F9),
                border: Border.all(color: const Color(0xFF94A3B8), style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.camera_alt_outlined, size: 40, color: Color(0xFF1E3A8A)),
                  SizedBox(height: 8),
                  Text('Photo Added (Compressed to 320KB)', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0F766E))),
                  Text('Device-side compression active for data efficiency', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                ],
              ),
            ),
            const SizedBox(height: 20),

            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Item Title',
                hintText: 'e.g. Financial Accounting 1B Textbook',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),

            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
              items: ['Textbooks', 'Stationery', 'Food/Meals', 'Clothing']
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() {
                _category = v!;
                final max = _categoryMaxLimits[_category]!;
                if (_creditCost > max) _creditCost = max;
              }),
            ),
            const SizedBox(height: 14),

            DropdownButtonFormField<String>(
              value: _condition,
              decoration: const InputDecoration(labelText: 'Condition', border: OutlineInputBorder()),
              items: ['Brand New', 'Like New', 'Good', 'Fair']
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() => _condition = v!),
            ),
            const SizedBox(height: 14),

            TextField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Description & Handover Notes',
                hintText: 'e.g. Prescribed for 2nd semester. Meet in Bedfordview library foyer.',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),

            // Credit Value Slider
            Text(
              'Credit Valuation: $_creditCost AmigoCredits',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF1E3A8A)),
            ),
            Slider(
              value: _creditCost.toDouble(),
              min: 5,
              max: (_categoryMaxLimits[_category] ?? 30).toDouble(),
              divisions: ((_categoryMaxLimits[_category] ?? 30) - 5) ~/ 5,
              label: '$_creditCost Credits',
              activeColor: const Color(0xFF0F766E),
              onChanged: (val) => setState(() => _creditCost = val.toInt()),
            ),
            Text(
              'Category Price Bracket: 5 to ${_categoryMaxLimits[_category]} Credits (Protects against inflation)',
              style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
            ),
            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: _isLoading ? null : _handleSubmit,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1E3A8A),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('PUBLISH TO CAMPUS FEED', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
