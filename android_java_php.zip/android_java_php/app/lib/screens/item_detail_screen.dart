// item_detail_screen.dart - Detailed View, Flagging, and Escrow Claiming

import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import 'qr_handover_screen.dart';

class ItemDetailScreen extends StatefulWidget {
  final ItemModel item;
  const ItemDetailScreen({Key? key, required this.item}) : super(key: key);

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  final _apiService = ApiService();
  bool _isLoading = false;

  void _handleClaim() async {
    final user = _apiService.currentUser!;
    if (user.creditBalance < widget.item.creditCost) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Insufficient AmigoCredits', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          content: Text(
            'You currently have ${user.creditBalance} credits, but this item requires ${widget.item.creditCost} credits.\n\nTo earn more credits, trade in an unused textbook or stationery pack with the campus community!',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
          ],
        ),
      );
      return;
    }

    // Confirmation dialog
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm Escrow Claim'),
        content: Text(
          'Claiming "${widget.item.title}" will reserve ${widget.item.creditCost} credits from your active balance into Escrow.\n\nCredits will only be released to the donor once you physically meet on campus and scan the QR code.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1E3A8A)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirm Claim'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _isLoading = true);
    final res = await _apiService.claimItem(widget.item.id);
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const QrHandoverScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  void _handleFlag() async {
    final res = await _apiService.flagListing(widget.item.id, 'Inappropriate or commercial content');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res['message'])),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final isOwner = _apiService.currentUser?.id == item.listedByUserId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Resource Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flag_outlined, color: Colors.amber),
            tooltip: 'Report Listing',
            onPressed: _handleFlag,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Hero Image
            Image.network(
              item.photoUrl,
              height: 250,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 250,
                color: Colors.grey[200],
                child: const Icon(Icons.image, size: 80, color: Colors.grey),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Chip(
                        label: Text(item.category, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0369A1))),
                        backgroundColor: const Color(0xFFE0F2FE),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0FDF4),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: const Color(0xFF16A34A)),
                        ),
                        child: Text(
                          '${item.creditCost} AmigoCredits',
                          style: const TextStyle(color: Color(0xFF16A34A), fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item.title,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Item Condition: ${item.condition}',
                    style: const TextStyle(color: Color(0xFF64748B), fontWeight: FontWeight.w600),
                  ),
                  const Divider(height: 30),
                  const Text('Description', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                  const SizedBox(height: 6),
                  Text(
                    item.description,
                    style: const TextStyle(fontSize: 14, color: Color(0xFF334155), height: 1.5),
                  ),
                  const Divider(height: 30),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFF1E3A8A),
                      child: Icon(Icons.person, color: Colors.white),
                    ),
                    title: Text(item.donorName, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: const Text('Verified Eduvos Student • Rating: 4.9 ★'),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: isOwner || _isLoading ? null : _handleClaim,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF16A34A),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            isOwner ? 'YOU OWN THIS LISTING' : 'CLAIM ITEM (${item.creditCost} CREDITS)',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
