// home_feed_screen.dart - Campus Discovery Feed with Category Filtering

import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import 'item_detail_screen.dart';
import 'upload_listing_screen.dart';
import 'wallet_screen.dart';
import 'qr_handover_screen.dart';
import 'moderator_screen.dart';

class HomeFeedScreen extends StatefulWidget {
  final VoidCallback onLogout;
  const HomeFeedScreen({Key? key, required this.onLogout}) : super(key: key);

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> {
  final _apiService = ApiService();
  String _selectedCategory = 'All';
  String _searchQuery = '';
  final _searchController = TextEditingController();

  final List<String> _categories = ['All', 'Textbooks', 'Stationery', 'Food/Meals', 'Clothing'];

  void _refresh() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final user = _apiService.currentUser!;
    final listings = _apiService.getActiveListings(
      category: _selectedCategory,
      query: _searchQuery,
    );

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('SharAmigo Campus Feed', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(user.campusName, style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        actions: [
          // Wallet Balance Chip Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            child: ActionChip(
              backgroundColor: const Color(0xFF0F766E),
              avatar: const Icon(Icons.account_balance_wallet, color: Colors.white, size: 16),
              label: Text(
                '${user.creditBalance} Pts',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const WalletScreen()),
              ).then((_) => _refresh()),
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (val) {
              if (val == 'logout') {
                widget.onLogout();
              } else if (val == 'moderator') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ModeratorScreen())).then((_) => _refresh());
              } else if (val == 'handover') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const QrHandoverScreen())).then((_) => _refresh());
              }
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'handover', child: Text('Active Handover Tickets')),
              if (user.role == 'ROLE_MODERATOR')
                const PopupMenuItem(value: 'moderator', child: Text('Moderator Dashboard')),
              const PopupMenuItem(value: 'logout', child: Text('Sign Out')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // SEARCH BAR
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search textbooks, meal vouchers, stationery...',
                prefixIcon: const Icon(Icons.search, color: Color(0xFF1E3A8A)),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                filled: true,
                fillColor: const Color(0xFFF1F5F9),
              ),
              onChanged: (val) => setState(() => _searchQuery = val),
            ),
          ),

          // CATEGORY CHIPS
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            color: Colors.white,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final cat = _categories[index];
                final isSelected = _selectedCategory == cat;
                return ChoiceChip(
                  label: Text(cat),
                  selected: isSelected,
                  selectedColor: const Color(0xFF1E3A8A),
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : const Color(0xFF334155),
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                  onSelected: (selected) {
                    if (selected) setState(() => _selectedCategory = cat);
                  },
                );
              },
            ),
          ),

          const Divider(height: 1),

          // LISTINGS LIST
          Expanded(
            child: listings.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.inventory_2_outlined, size: 64, color: Color(0xFF94A3B8)),
                        SizedBox(height: 12),
                        Text('No active listings found in this category.', style: TextStyle(color: Color(0xFF64748B), fontSize: 16)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: listings.length,
                    itemBuilder: (context, index) {
                      final item = listings[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)),
                            );
                            _refresh();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Thumbnail
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    item.photoUrl,
                                    width: 90,
                                    height: 90,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      width: 90,
                                      height: 90,
                                      color: const Color(0xFFE2E8F0),
                                      child: const Icon(Icons.image, color: Colors.grey),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 14),

                                // Content
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFE0F2FE),
                                              borderRadius: BorderRadius.circular(4),
                                            ),
                                            child: Text(
                                              item.category,
                                              style: const TextStyle(color: Color(0xFF0369A1), fontSize: 11, fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Text(
                                            '${item.creditCost} Credits',
                                            style: const TextStyle(color: Color(0xFF16A34A), fontWeight: FontWeight.bold, fontSize: 14),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        item.title,
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1E293B)),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'Donor: ${item.donorName} • Cond: ${item.condition}',
                                        style: const TextStyle(color: Color(0xFF64748B), fontSize: 12),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF1E3A8A),
        icon: const Icon(Icons.add_photo_alternate),
        label: const Text('Trade-In Resource', style: TextStyle(fontWeight: FontWeight.bold)),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const UploadListingScreen()),
          );
          _refresh();
        },
      ),
    );
  }
}
