// auth_screen.dart - Campus Domain Registration and Login

import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onAuthSuccess;
  const AuthScreen({Key? key, required this.onAuthSuccess}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _apiService = ApiService();

  // Register Fields
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _studentNumController = TextEditingController();
  final _passwordController = TextEditingController();
  final _otpController = TextEditingController();
  String _selectedCampus = 'Eduvos - Bedfordview';
  bool _otpSent = false;
  bool _isLoading = false;

  // Login Fields
  final _loginEmailController = TextEditingController();
  final _loginPasswordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  void _handleSendOtp() async {
    if (_emailController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your university student email.')),
      );
      return;
    }

    setState(() => _isLoading = true);
    final res = await _apiService.requestRegistrationOtp(_emailController.text.trim());
    setState(() => _isLoading = false);

    if (res['success']) {
      setState(() => _otpSent = true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  void _handleRegister() async {
    setState(() => _isLoading = true);
    final res = await _apiService.completeRegistration(
      fullName: _nameController.text.trim(),
      email: _emailController.text.trim(),
      studentNumber: _studentNumController.text.trim(),
      campusName: _selectedCampus,
      password: _passwordController.text,
      enteredOtp: _otpController.text.trim(),
    );
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      widget.onAuthSuccess();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  void _handleLogin() async {
    setState(() => _isLoading = true);
    final res = await _apiService.login(
      _loginEmailController.text.trim(),
      _loginPasswordController.text,
    );
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      widget.onAuthSuccess();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('SharAmigo', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFF0F766E),
          labelColor: Colors.white,
          tabs: const [
            Tab(text: 'Register (OTP)'),
            Tab(text: 'Sign In'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // REGISTER TAB
          SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Join Campus Sharing Network',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A)),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Restricted to accredited South African university domains (@eduvos.com, @student.uj.ac.za, etc.).',
                  style: TextStyle(color: Color(0xFF64748B), fontSize: 13),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _studentNumController,
                  decoration: const InputDecoration(labelText: 'Student Number', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: 'Student Email Address',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.send),
                      onPressed: _isLoading ? null : _handleSendOtp,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _selectedCampus,
                  decoration: const InputDecoration(labelText: 'Campus Hub', border: OutlineInputBorder()),
                  items: ['Eduvos - Bedfordview', 'Eduvos - Midrand', 'Eduvos - Pretoria']
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedCampus = v!),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
                ),
                if (_otpSent) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0FDF4),
                      border: Border.all(color: Colors.green),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Enter 6-Digit OTP Code (Demo OTP: 849201):', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                        const SizedBox(height: 8),
                        TextField(
                          controller: _otpController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            hintText: '849201',
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading ? null : (_otpSent ? _handleRegister : _handleSendOtp),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: const Color(0xFF1E3A8A),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(_otpSent ? 'VERIFY OTP & REGISTER (+10 PTS)' : 'REQUEST OTP CODE', style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),

          // SIGN IN TAB
          SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Welcome Back to SharAmigo',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A)),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _loginEmailController,
                  decoration: const InputDecoration(labelText: 'Student Email', border: OutlineInputBorder(), hintText: 'mbalenhle@student.eduvos.com'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _loginPasswordController,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading ? null : _handleLogin,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: const Color(0xFF0F766E),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('SIGN IN TO CAMPUS FEED', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 20),
                const Divider(),
                const SizedBox(height: 10),
                const Text('Quick Demo Accounts (One-Click Switch):', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    ActionChip(
                      avatar: const Icon(Icons.person, size: 16),
                      label: const Text('Student Receiver (Mbalenhle)'),
                      onPressed: () {
                        _apiService.switchUser('usr-receiver-002');
                        widget.onAuthSuccess();
                      },
                    ),
                    ActionChip(
                      avatar: const Icon(Icons.volunteer_activism, size: 16),
                      label: const Text('Student Donor (Zachariah)'),
                      onPressed: () {
                        _apiService.switchUser('usr-donor-001');
                        widget.onAuthSuccess();
                      },
                    ),
                    ActionChip(
                      avatar: const Icon(Icons.admin_panel_settings, size: 16),
                      label: const Text('Campus Moderator'),
                      onPressed: () {
                        _apiService.switchUser('usr-mod-003');
                        widget.onAuthSuccess();
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
