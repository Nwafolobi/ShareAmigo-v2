// wallet_screen.dart - Points Wallet, Escrow Balance Breakdown, and POPIA Audit Ledger

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final apiService = ApiService();
    final user = apiService.currentUser!;
    final userTxns = apiService.getUserTransactions(user.id);
    final escrowHeld = apiService.getEscrowHeldBalance(user.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AmigoWallet & Ledger'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // WALLET BALANCE CARD
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1E3A8A), Color(0xFF0F766E)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ACTIVE WALLET BALANCE', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text(
                        '${user.creditBalance}',
                        style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(width: 8),
                      const Text('AmigoCredits', style: TextStyle(color: Colors.white, fontSize: 18)),
                    ],
                  ),
                  const Divider(color: Colors.white24, height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Available to Spend', style: TextStyle(color: Colors.white70, fontSize: 11)),
                          Text('${user.creditBalance} Pts', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text('Reserved in Escrow', style: TextStyle(color: Colors.white70, fontSize: 11)),
                          Text('$escrowHeld Pts', style: const TextStyle(color: Color(0xFFFDE68A), fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // AUDIT STATEMENT HEADER
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Immutable Transaction Ledger', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF1E293B))),
                TextButton.icon(
                  icon: const Icon(Icons.download, size: 16),
                  label: const Text('Export Statement'),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('POPIA Compliant Statement exported (PDF/CSV simulated).')),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),

            // LEDGER ITEMS
            if (userTxns.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                alignment: Alignment.center,
                child: const Text('No transactions yet. Start by trading or claiming a resource!'),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: userTxns.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final txn = userTxns[index];
                  final isDonor = txn.donorId == user.id;
                  final isCompleted = txn.status == TransactionStatus.completed;

                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                    leading: CircleAvatar(
                      backgroundColor: isDonor ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                      child: Icon(
                        isDonor ? Icons.arrow_downward : Icons.arrow_upward,
                        color: isDonor ? const Color(0xFF16A34A) : const Color(0xFFDC2626),
                      ),
                    ),
                    title: Text(txn.itemTitle, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    subtitle: Text(
                      '${isDonor ? 'Traded to' : 'Claimed from'}: ${isDonor ? txn.receiverName : txn.donorName}\n${DateFormat('yyyy-MM-dd HH:mm').format(txn.createdAt)} • Status: ${txn.status.name.toUpperCase()}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    trailing: Text(
                      '${isDonor ? '+' : '-'}${txn.creditAmount} Pts',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: isDonor ? const Color(0xFF16A34A) : const Color(0xFFDC2626),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
