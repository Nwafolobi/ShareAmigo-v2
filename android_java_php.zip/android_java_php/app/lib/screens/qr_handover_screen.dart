// qr_handover_screen.dart - Dynamic QR Handoff Ticket & Scanner Simulator

import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class QrHandoverScreen extends StatefulWidget {
  const QrHandoverScreen({Key? key}) : super(key: key);

  @override
  State<QrHandoverScreen> createState() => _QrHandoverScreenState();
}

class _QrHandoverScreenState extends State<QrHandoverScreen> {
  final _apiService = ApiService();
  final _manualPinController = TextEditingController();
  bool _isLoading = false;

  void _handleSimulateScan(TransactionModel txn) async {
    setState(() => _isLoading = true);
    final res = await _apiService.verifyAndCompleteHandover(
      transactionId: txn.id,
      qrHashOrPin: txn.qrVerifyHash,
    );
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  void _handleManualPinVerify(TransactionModel txn) async {
    setState(() => _isLoading = true);
    final res = await _apiService.verifyAndCompleteHandover(
      transactionId: txn.id,
      qrHashOrPin: _manualPinController.text.trim(),
    );
    setState(() => _isLoading = false);

    if (res['success']) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(res['message'])),
      );
      _manualPinController.clear();
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(res['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _apiService.currentUser!;
    final userTransactions = _apiService.getUserTransactions(user.id);
    final pendingTxns = userTransactions.where((t) => t.status == TransactionStatus.pending).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Active Handover Tickets'),
      ),
      body: pendingTxns.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.qr_code_2_outlined, size: 70, color: Color(0xFF94A3B8)),
                  SizedBox(height: 12),
                  Text('No pending handovers right now.', style: TextStyle(color: Color(0xFF64748B), fontSize: 16)),
                  Text('Claim an item or wait for a student to claim yours!', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: pendingTxns.length,
              itemBuilder: (context, index) {
                final txn = pendingTxns[index];
                final isReceiver = txn.receiverId == user.id;

                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.only(bottom: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              isReceiver ? 'YOU ARE CLAIMING:' : 'YOU ARE DONATING:',
                              style: TextStyle(
                                color: isReceiver ? const Color(0xFF0369A1) : const Color(0xFF0F766E),
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFEF3C7),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text('ESCROW PENDING', style: TextStyle(color: Color(0xFF92400E), fontSize: 11, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(txn.itemTitle, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0F172A))),
                        const SizedBox(height: 4),
                        Text(
                          isReceiver ? 'Donor: ${txn.donorName} • Escrow: ${txn.creditAmount} Pts' : 'Receiver: ${txn.receiverName} • Payout: ${txn.creditAmount} Pts',
                          style: const TextStyle(color: Color(0xFF64748B), fontSize: 13),
                        ),
                        const Divider(height: 24),

                        if (isReceiver) ...[
                          // RECEIVER SHOWS QR CODE
                          const Center(
                            child: Text(
                              'Present this QR Code to the donor on campus:',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Center(
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(color: Colors.black, width: 2),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                children: [
                                  const Icon(Icons.qr_code_2, size: 140, color: Color(0xFF1E3A8A)),
                                  const SizedBox(height: 6),
                                  Text(
                                    'PIN Fallback: ${txn.pinFallback}',
                                    style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 16, color: Color(0xFF0F766E)),
                                  ),
                                  const Text('Dynamic QR rotates every 60s for safety', style: TextStyle(fontSize: 10, color: Colors.grey)),
                                ],
                              ),
                            ),
                          ),
                        ] else ...[
                          // DONOR SCANS QR CODE
                          const Text(
                            'Meet receiver on campus. Inspect item and scan their QR code to release your credits:',
                            style: TextStyle(fontSize: 13, height: 1.4),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton.icon(
                            onPressed: _isLoading ? null : () => _handleSimulateScan(txn),
                            icon: const Icon(Icons.qr_code_scanner),
                            label: const Text('SCAN RECEIVER QR CODE (COMPLETE EXCHANGE)', style: TextStyle(fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF16A34A),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: TextField(
                                  controller: _manualPinController,
                                  decoration: const InputDecoration(hintText: 'Enter 6-digit fallback PIN', border: OutlineInputBorder(), isDense: true),
                                ),
                              ),
                              const SizedBox(width: 8),
                              OutlinedButton(
                                onPressed: _isLoading ? null : () => _handleManualPinVerify(txn),
                                child: const Text('Submit PIN'),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
