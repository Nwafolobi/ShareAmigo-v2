// moderator_screen.dart - Campus Moderator Dashboard for Flagged Content Review

import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class ModeratorScreen extends StatefulWidget {
  const ModeratorScreen({Key? key}) : super(key: key);

  @override
  State<ModeratorScreen> createState() => _ModeratorScreenState();
}

class _ModeratorScreenState extends State<ModeratorScreen> {
  final _apiService = ApiService();

  void _handleDelete(ItemModel item) async {
    final res = await _apiService.deleteListing(item.id);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res['message'])),
    );
    setState(() {});
  }

  void _handleDismiss(ItemModel item) {
    setState(() {
      item.flagCount = 0;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Flag dismissed. Listing remains active.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final reportedItems = _apiService.getReportedItems();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Moderator Dashboard'),
        backgroundColor: const Color(0xFF334155),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF2F2),
                border: Border.all(color: const Color(0xFFEF4444)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: const [
                  Icon(Icons.shield_outlined, color: Colors.red),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Campus Safety Queue: Review listings flagged by verified students for policy violations.',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF991B1B)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Flagged Items (${reportedItems.length})',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF1E293B)),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: reportedItems.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.check_circle_outline, size: 60, color: Colors.green),
                          SizedBox(height: 10),
                          Text('Moderation queue is clean. No reported items.', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: reportedItems.length,
                      itemBuilder: (context, index) {
                        final item = reportedItems[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(color: Colors.red[100], borderRadius: BorderRadius.circular(4)),
                                      child: Text('${item.flagCount} Reports', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 11)),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text('Donor: ${item.donorName} • Category: ${item.category}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                                const SizedBox(height: 8),
                                Text(item.description, style: const TextStyle(fontSize: 13)),
                                const SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    TextButton(
                                      onPressed: () => _handleDismiss(item),
                                      child: const Text('Dismiss Report'),
                                    ),
                                    const SizedBox(width: 8),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                      onPressed: () => _handleDelete(item),
                                      child: const Text('Remove Listing'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
