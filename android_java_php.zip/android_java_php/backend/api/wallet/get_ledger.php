<?php
// get_ledger.php - Retrieve User Wallet Balance and Chronological Audit Ledger

require_once '../../config/db.php';

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid or missing user_id.']);
    exit();
}

// 1. Get User Balance
$user_stmt = $pdo->prepare("SELECT id, full_name, credit_balance FROM users WHERE id = ?");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();

if (!$user) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'User not found.']);
    exit();
}

// 2. Get Escrow Reserved Balance
$escrow_stmt = $pdo->prepare("SELECT COALESCE(SUM(held_credits), 0) as escrow_held FROM escrow_holds WHERE user_id = ? AND status = 'Held'");
$escrow_stmt->execute([$user_id]);
$escrow = $escrow_stmt->fetch();

// 3. Get User Transaction History
$tx_stmt = $pdo->prepare("
    SELECT t.id, t.item_id, i.title as item_title, t.donor_id, d.full_name as donor_name, 
           t.receiver_id, r.full_name as receiver_name, t.credit_amount, t.status, t.created_at, t.completed_at
    FROM transactions t
    JOIN items i ON t.item_id = i.id
    JOIN users d ON t.donor_id = d.id
    JOIN users r ON t.receiver_id = r.id
    WHERE t.donor_id = ? OR t.receiver_id = ?
    ORDER BY t.created_at DESC
");
$tx_stmt->execute([$user_id, $user_id]);
$transactions = $tx_stmt->fetchAll();

echo json_encode([
    'success' => true,
    'user_id' => $user['id'],
    'full_name' => $user['full_name'],
    'credit_balance' => (int)$user['credit_balance'],
    'escrow_held' => (int)$escrow['escrow_held'],
    'transactions' => $transactions
]);
?>
