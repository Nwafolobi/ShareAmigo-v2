<?php
// verify_qr.php - Release Escrow and Finalize Physical Handoff

require_once '../../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['transaction_id']) || !isset($data['donor_id']) || !isset($data['qr_hash_or_pin'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing transaction_id, donor_id, or qr_hash_or_pin.']);
    exit();
}

$transaction_id = (int)$data['transaction_id'];
$donor_id = (int)$data['donor_id'];
$code = trim($data['qr_hash_or_pin']);

try {
    $pdo->beginTransaction();

    // 1. Lock Transaction Row
    $tx_stmt = $pdo->prepare("SELECT id, item_id, donor_id, receiver_id, credit_amount, status, qr_verify_hash, pin_fallback FROM transactions WHERE id = ? FOR UPDATE");
    $tx_stmt->execute([$transaction_id]);
    $tx = $tx_stmt->fetch();

    if (!$tx || $tx['status'] !== 'Pending') {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid, expired, or already completed transaction.']);
        exit();
    }

    if ($tx['donor_id'] != $donor_id) {
        $pdo->rollBack();
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized donor attempting verification.']);
        exit();
    }

    // 2. Validate Code
    if ($tx['qr_verify_hash'] !== $code && $tx['pin_fallback'] !== $code) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid QR verification hash or PIN.']);
        exit();
    }

    // 3. Release points to Donor
    $donor_stmt = $pdo->prepare("UPDATE users SET credit_balance = credit_balance + ? WHERE id = ?");
    $donor_stmt->execute([$tx['credit_amount'], $donor_id]);

    // 4. Update Escrow Hold to Released
    $escrow_stmt = $pdo->prepare("UPDATE escrow_holds SET status = 'Released' WHERE transaction_id = ?");
    $escrow_stmt->execute([$transaction_id]);

    // 5. Update Item status to Exchanged
    $item_stmt = $pdo->prepare("UPDATE items SET status = 'Exchanged' WHERE id = ?");
    $item_stmt->execute([$tx['item_id']]);

    // 6. Complete Transaction
    $complete_stmt = $pdo->prepare("UPDATE transactions SET status = 'Completed', completed_at = CURRENT_TIMESTAMP WHERE id = ?");
    $complete_stmt->execute([$transaction_id]);

    // 7. Log Audit
    $audit_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'ESCROW_RELEASE_COMPLETE', ?)");
    $audit_stmt->execute([$donor_id, json_encode(['transaction_id' => $transaction_id, 'credits_received' => $tx['credit_amount']])]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => "Exchange verified! +{$tx['credit_amount']} AmigoCredits added to your wallet.",
        'transaction_id' => $transaction_id
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error during QR verification: ' . $e->getMessage()]);
}
?>
