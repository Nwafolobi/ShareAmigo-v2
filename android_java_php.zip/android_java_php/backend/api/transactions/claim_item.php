<?php
// claim_item.php - Two-Phase Commit Escrow Reservation with Row Locking

require_once '../../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['item_id']) || !isset($data['receiver_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing item_id or receiver_id.']);
    exit();
}

$item_id = (int)$data['item_id'];
$receiver_id = (int)$data['receiver_id'];

try {
    $pdo->beginTransaction();

    // 1. Lock Item row to prevent simultaneous claims
    $item_stmt = $pdo->prepare("SELECT id, listed_by, title, credit_cost, status FROM items WHERE id = ? FOR UPDATE");
    $item_stmt->execute([$item_id]);
    $item = $item_stmt->fetch();

    if (!$item || $item['status'] !== 'Available') {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Item has already been claimed by another student.']);
        exit();
    }

    if ($item['listed_by'] == $receiver_id) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'You cannot claim your own listed item.']);
        exit();
    }

    // 2. Lock Receiver row and check credit balance
    $user_stmt = $pdo->prepare("SELECT id, credit_balance FROM users WHERE id = ? FOR UPDATE");
    $user_stmt->execute([$receiver_id]);
    $receiver = $user_stmt->fetch();

    if (!$receiver || $receiver['credit_balance'] < $item['credit_cost']) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => "Insufficient AmigoCredits. You have {$receiver['credit_balance']} credits, but this item requires {$item['credit_cost']} credits."
        ]);
        exit();
    }

    // 3. Deduct points from receiver to Escrow
    $deduct_stmt = $pdo->prepare("UPDATE users SET credit_balance = credit_balance - ? WHERE id = ?");
    $deduct_stmt->execute([$item['credit_cost'], $receiver_id]);

    // 4. Update item status to Escrow
    $update_item_stmt = $pdo->prepare("UPDATE items SET status = 'Escrow' WHERE id = ?");
    $update_item_stmt->execute([$item_id]);

    // 5. Generate QR Hash and Fallback PIN
    $qr_hash = md5($item_id . '-' . $receiver_id . '-' . time() . '-' . uniqid());
    $pin_fallback = '849201';

    // 6. Create Transaction Record
    $tx_stmt = $pdo->prepare("INSERT INTO transactions (item_id, donor_id, receiver_id, credit_amount, status, qr_verify_hash, pin_fallback) VALUES (?, ?, ?, ?, 'Pending', ?, ?)");
    $tx_stmt->execute([$item_id, $item['listed_by'], $receiver_id, $item['credit_cost'], $qr_hash, $pin_fallback]);
    $transaction_id = $pdo->lastInsertId();

    // 7. Create Escrow Hold Record
    $escrow_stmt = $pdo->prepare("INSERT INTO escrow_holds (transaction_id, user_id, held_credits, status) VALUES (?, ?, ?, 'Held')");
    $escrow_stmt->execute([$transaction_id, $receiver_id, $item['credit_cost']]);

    // 8. Log Audit
    $audit_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'ESCROW_CLAIM_LOCK', ?)");
    $audit_stmt->execute([$receiver_id, json_encode(['transaction_id' => $transaction_id, 'credits_held' => $item['credit_cost']])]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Item successfully reserved! Credits placed in Escrow.',
        'transaction' => [
            'id' => $transaction_id,
            'item_title' => $item['title'],
            'credit_amount' => $item['credit_cost'],
            'qr_verify_hash' => $qr_hash,
            'pin_fallback' => $pin_fallback,
            'status' => 'Pending'
        ]
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
}
?>
