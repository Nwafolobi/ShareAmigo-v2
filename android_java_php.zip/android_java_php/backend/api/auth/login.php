<?php
// login.php - Authenticate Student Credentials

require_once '../../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email and password required.']);
    exit();
}

$email = strtolower(trim($data['email']));
$password = $data['password'];

$stmt = $pdo->prepare("SELECT u.id, u.campus_id, c.name as campus_name, u.full_name, u.email, u.student_number, u.password_hash, u.credit_balance, u.role FROM users u JOIN campuses c ON u.campus_id = c.id WHERE u.email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
    exit();
}

unset($user['password_hash']);

echo json_encode([
    'success' => true,
    'message' => 'Login successful.',
    'user' => $user
]);
?>
