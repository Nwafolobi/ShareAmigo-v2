<?php
// register.php - Register student with domain validation & OTP

require_once '../../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['full_name']) || !isset($data['password']) || !isset($data['student_number'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required registration parameters.']);
    exit();
}

$email = strtolower(trim($data['email']));
$full_name = trim($data['full_name']);
$student_number = trim($data['student_number']);
$password = $data['password'];
$campus_id = isset($data['campus_id']) ? (int)$data['campus_id'] : 1;

// 1. Validate Email Domain
$domain_whitelist = ['eduvos.com', 'student.eduvos.com', 'student.uj.ac.za', 'students.wits.ac.za', 'myuct.ac.za', 'student.ukzn.ac.za', 'ufs4life.ac.za'];
$email_parts = explode('@', $email);
$domain = end($email_parts);

if (!in_array($domain, $domain_whitelist)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Registration restricted to accredited university student email domains (@eduvos.com, @student.uj.ac.za, etc.).'
    ]);
    exit();
}

// 2. Check if Email Already Exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'A student account with this email already exists.']);
    exit();
}

// 3. Hash Password & Insert User with 10 Starter Credits
$password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
$credit_balance = 10; // Starter Credits

try {
    $insert_stmt = $pdo->prepare("INSERT INTO users (campus_id, full_name, email, student_number, password_hash, credit_balance, is_verified, role) VALUES (?, ?, ?, ?, ?, ?, 1, 'ROLE_STUDENT')");
    $insert_stmt->execute([$campus_id, $full_name, $email, $student_number, $password_hash, $credit_balance]);
    $new_user_id = $pdo->lastInsertId();

    // Log Audit
    $audit_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'ACCOUNT_REGISTERED', ?)");
    $audit_stmt->execute([$new_user_id, json_encode(['starter_credits' => 10, 'email' => $email])]);

    http_response_code(201);
    echo json_encode([
        'success' => true,
        'message' => 'Account created successfully! +10 Starter AmigoCredits added to your wallet.',
        'user' => [
            'id' => $new_user_id,
            'full_name' => $full_name,
            'email' => $email,
            'student_number' => $student_number,
            'credit_balance' => $credit_balance,
            'role' => 'ROLE_STUDENT'
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error during registration: ' . $e->getMessage()]);
}
?>
