<?php
// get_items.php - Retrieve active listings with category and keyword search

require_once '../../config/db.php';

$category = isset($_GET['category']) ? trim($_GET['category']) : 'All';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$campus_id = isset($_GET['campus_id']) ? (int)$_GET['campus_id'] : 1;

$sql = "SELECT i.id, i.listed_by, u.full_name as donor_name, i.campus_id, c.name as category_name, i.title, i.description, i.condition_status, i.credit_cost, i.status, i.photo_url, i.created_at 
        FROM items i 
        JOIN users u ON i.listed_by = u.id 
        JOIN categories c ON i.category_id = c.id 
        WHERE i.campus_id = ? AND i.status = 'Available'";

$params = [$campus_id];

if ($category !== 'All' && !empty($category)) {
    $sql .= " AND c.name = ?";
    $params[] = $category;
}

if (!empty($search)) {
    $sql .= " AND (i.title LIKE ? OR i.description LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY i.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

echo json_encode([
    'success' => true,
    'count' => count($items),
    'items' => $items
]);
?>
