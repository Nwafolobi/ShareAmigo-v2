<?php
// create_item.php - Upload and list a surplus resource

require_once '../../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['user_id']) || !isset($data['title']) || !isset($data['category_name']) || !isset($data['credit_cost']) || !isset($data['condition_status'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required item listing fields.']);
    exit();
}

$user_id = (int)$data['user_id'];
$title = trim($data['title']);
$category_name = trim($data['category_name']);
$description = isset($data['description']) ? trim($data['description']) : '';
$condition_status = $data['condition_status'];
$credit_cost = (int)$data['credit_cost'];
$photo_url = isset($data['photo_url']) && !empty($data['photo_url']) ? $data['photo_url'] : 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400';
$campus_id = isset($data['campus_id']) ? (int)$data['campus_id'] : 1;

// 1. Get Category ID and Max Price Cap
$cat_stmt = $pdo->prepare("SELECT id, max_credit_limit FROM categories WHERE name = ?");
$cat_stmt->execute([$category_name]);
$category = $cat_stmt->fetch();

if (!$category) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid category selected.']);
    exit();
}

if ($credit_cost > $category['max_credit_limit']) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => "Credit cost exceeds category maximum limit of {$category['max_credit_limit']} credits."
    ]);
    exit();
}

try {
    $insert_stmt = $pdo->prepare("INSERT INTO items (listed_by, campus_id, category_id, title, description, condition_status, credit_cost, status, photo_url) VALUES (?, ?, ?, ?, ?, ?, ?, 'Available', ?)");
    $insert_stmt->execute([$user_id, $campus_id, $category['id'], $title, $description, $condition_status, $credit_cost, $photo_url]);
    $item_id = $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'message' => 'Resource successfully published to campus feed!',
        'item_id' => $item_id
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
