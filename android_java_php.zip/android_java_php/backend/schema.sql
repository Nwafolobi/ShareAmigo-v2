-- ============================================================================
-- SHARAMIGO MYSQL DATABASE SCHEMA (InnoDB Engine for ACID Transactions)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS sharamigo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sharamigo_db;

-- 1. Campuses Table
CREATE TABLE IF NOT EXISTS campuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    domain_whitelist VARCHAR(100) NOT NULL, -- e.g. '@eduvos.com'
    physical_address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    campus_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    student_number VARCHAR(50) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    credit_balance INT NOT NULL DEFAULT 10,
    is_verified TINYINT(1) NOT NULL DEFAULT 0,
    role ENUM('ROLE_STUDENT', 'ROLE_MODERATOR') DEFAULT 'ROLE_STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (campus_id) REFERENCES campuses(id) ON DELETE RESTRICT,
    CONSTRAINT chk_credit_balance CHECK (credit_balance >= 0)
) ENGINE=InnoDB;

-- 3. Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE, -- 'Textbooks', 'Stationery', 'Food/Meals', 'Clothing'
    max_credit_limit INT NOT NULL DEFAULT 30,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Items Table
CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    listed_by INT NOT NULL,
    campus_id INT NOT NULL,
    category_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    condition_status ENUM('Brand New', 'Like New', 'Good', 'Fair') NOT NULL,
    credit_cost INT NOT NULL,
    status ENUM('Available', 'Escrow', 'Exchanged', 'Deleted') DEFAULT 'Available',
    photo_url TEXT,
    flag_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (listed_by) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (campus_id) REFERENCES campuses(id) ON DELETE RESTRICT,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    CONSTRAINT chk_credit_cost CHECK (credit_cost > 0)
) ENGINE=InnoDB;

-- 5. Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    donor_id INT NOT NULL,
    receiver_id INT NOT NULL,
    credit_amount INT NOT NULL,
    status ENUM('Pending', 'Completed', 'Cancelled', 'Disputed') DEFAULT 'Pending',
    qr_verify_hash VARCHAR(255) NOT NULL UNIQUE,
    pin_fallback VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE RESTRICT,
    FOREIGN KEY (donor_id) REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 6. Escrow Holds Table
CREATE TABLE IF NOT EXISTS escrow_holds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NOT NULL UNIQUE,
    user_id INT NOT NULL,
    held_credits INT NOT NULL,
    status ENUM('Held', 'Released', 'Refunded') DEFAULT 'Held',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 7. Audit Logs Table (POPIA Compliance & Financial Integrity)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    details JSON NOT NULL,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 8. Seed Initial Data
INSERT INTO campuses (name, domain_whitelist, physical_address) VALUES
('Eduvos - Bedfordview', 'eduvos.com', '140 Western Service Rd, Woodmead, Sandton, 2191'),
('Eduvos - Midrand', 'eduvos.com', '44 Bekker Rd, Vorna Valley, Midrand, 1686');

INSERT INTO categories (name, max_credit_limit) VALUES
('Textbooks', 30),
('Stationery', 20),
('Food/Meals', 15),
('Clothing', 20);

INSERT INTO users (campus_id, full_name, email, student_number, password_hash, credit_balance, is_verified, role) VALUES
(1, 'Zachariah Ebrahim', 'zach@student.eduvos.com', 'EDU-2024-8841', '$2y$10$e8w6QeM3mY4i2.J5zVp1kO7mQ8f.7bH5vB8kQ3z2y1.J5zVp1kO7m', 35, 1, 'ROLE_STUDENT'),
(1, 'Mbalenhle Rampedi', 'mbalenhle@student.eduvos.com', 'EDU-2025-1049', '$2y$10$e8w6QeM3mY4i2.J5zVp1kO7mQ8f.7bH5vB8kQ3z2y1.J5zVp1kO7m', 25, 1, 'ROLE_STUDENT'),
(1, 'Campus Admin', 'moderator@eduvos.com', 'EMP-MOD-01', '$2y$10$e8w6QeM3mY4i2.J5zVp1kO7mQ8f.7bH5vB8kQ3z2y1.J5zVp1kO7m', 100, 1, 'ROLE_MODERATOR');

INSERT INTO items (listed_by, campus_id, category_id, title, description, condition_status, credit_cost, status, photo_url) VALUES
(1, 1, 1, 'Information Systems 2A Prescribed Book', 'Hardcover textbook for ITDMA3. Clean pages with minor pencil notes.', 'Good', 15, 'Available', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400'),
(1, 1, 2, 'Casio Scientific Calculator FX-82ZA Plus II', 'South African curriculum approved calculator with protective cover.', 'Like New', 20, 'Available', 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=400'),
(1, 1, 3, 'Campus Cafeteria Meal Vouchers (Pack of 5)', 'Unused meal vouchers valid at Bedfordview Cafeteria.', 'Brand New', 10, 'Available', 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400');
