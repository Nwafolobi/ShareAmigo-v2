package com.eduvos.sharamigo.activities;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.eduvos.sharamigo.R;
import com.eduvos.sharamigo.network.ApiClient;
import com.google.android.material.button.MaterialButton;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QrHandoverActivity extends AppCompatActivity {

    private ImageView ivQrCode;
    private TextView tvPinFallback;
    private MaterialButton btnSimulateDonorScan;

    private int currentUserId;
    private int transactionId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_handover);

        currentUserId = getIntent().getIntExtra("USER_ID", 2);

        ivQrCode = findViewById(R.id.ivQrCode);
        tvPinFallback = findViewById(R.id.tvPinFallback);
        btnSimulateDonorScan = findViewById(R.id.btnSimulateDonorScan);

        generateQrCode("SHARAMIGO-TXN-" + transactionId + "-USER-" + currentUserId);

        btnSimulateDonorScan.setOnClickListener(v -> completeHandoff());
    }

    private void generateQrCode(String data) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(data, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            ivQrCode.setImageBitmap(bmp);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private void completeHandoff() {
        btnSimulateDonorScan.setEnabled(false);

        Map<String, Object> body = new HashMap<>();
        body.put("transaction_id", transactionId);
        body.put("donor_id", 1); // Zachariah
        body.put("qr_hash_or_pin", "849201");

        ApiClient.getService().verifyQr(body).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                btnSimulateDonorScan.setEnabled(true);
                Toast.makeText(QrHandoverActivity.this, "Exchange Completed! Credits released.", Toast.LENGTH_LONG).show();
                finish();
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                btnSimulateDonorScan.setEnabled(true);
                Toast.makeText(QrHandoverActivity.this, "Exchange Completed! (Offline Demo)", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
