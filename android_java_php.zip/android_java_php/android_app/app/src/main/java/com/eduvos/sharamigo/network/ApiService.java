package com.eduvos.sharamigo.network;

import com.eduvos.sharamigo.models.*;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    @POST("auth/register.php")
    Call<Map<String, Object>> register(@Body Map<String, Object> body);

    @POST("auth/login.php")
    Call<Map<String, Object>> login(@Body Map<String, Object> body);

    @GET("items/get_items.php")
    Call<Map<String, Object>> getItems(
            @Query("category") String category,
            @Query("search") String search,
            @Query("campus_id") int campusId
    );

    @POST("items/create_item.php")
    Call<Map<String, Object>> createItem(@Body Map<String, Object> body);

    @POST("transactions/claim_item.php")
    Call<Map<String, Object>> claimItem(@Body Map<String, Object> body);

    @POST("transactions/verify_qr.php")
    Call<Map<String, Object>> verifyQr(@Body Map<String, Object> body);

    @GET("wallet/get_ledger.php")
    Call<Map<String, Object>> getLedger(@Query("user_id") int userId);
}
