package com.eduvos.sharamigo.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.eduvos.sharamigo.R;
import com.eduvos.sharamigo.adapters.ItemAdapter;
import com.eduvos.sharamigo.models.Item;
import com.eduvos.sharamigo.network.ApiClient;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFeedActivity extends AppCompatActivity {

    private RecyclerView rvItems;
    private ItemAdapter adapter;
    private List<Item> itemList = new ArrayList<>();
    private int currentUserId = 2; // Default to Mbalenhle
    private String selectedCategory = "All";
    private String searchQuery = "";

    private MaterialButton btnWalletBalance;
    private EditText etSearch;
    private ChipGroup chipGroupCategories;
    private ExtendedFloatingActionButton fabUpload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_feed);

        currentUserId = getIntent().getIntExtra("USER_ID", 2);

        btnWalletBalance = findViewById(R.id.btnWalletBalance);
        etSearch = findViewById(R.id.etSearch);
        chipGroupCategories = findViewById(R.id.chipGroupCategories);
        fabUpload = findViewById(R.id.fabUpload);
        rvItems = findViewById(R.id.rvItems);

        rvItems.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(this, itemList, currentUserId);
        rvItems.setAdapter(adapter);

        btnWalletBalance.setOnClickListener(v -> {
            Intent intent = new Intent(this, WalletActivity.class);
            intent.putExtra("USER_ID", currentUserId);
            startActivity(intent);
        });

        fabUpload.setOnClickListener(v -> {
            Intent intent = new Intent(this, UploadItemActivity.class);
            intent.putExtra("USER_ID", currentUserId);
            startActivity(intent);
        });

        setupCategoryChips();
        setupSearch();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    private void setupCategoryChips() {
        chipGroupCategories.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) {
                selectedCategory = "All";
            } else {
                int id = checkedIds.get(0);
                if (id == R.id.chipTextbooks) selectedCategory = "Textbooks";
                else if (id == R.id.chipStationery) selectedCategory = "Stationery";
                else if (id == R.id.chipFood) selectedCategory = "Food/Meals";
                else if (id == R.id.chipClothing) selectedCategory = "Clothing";
                else selectedCategory = "All";
            }
            loadItems();
        });
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString();
                loadItems();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void loadItems() {
        ApiClient.getService().getItems(selectedCategory, searchQuery, 1).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Gson gson = new Gson();
                    String json = gson.toJson(response.body().get("items"));
                    List<Item> fetched = gson.fromJson(json, new TypeToken<List<Item>>(){}.getType());
                    itemList.clear();
                    if (fetched != null) {
                        itemList.addAll(fetched);
                    }
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                // Offline fallback simulation
                Toast.makeText(HomeFeedActivity.this, "Offline cache loaded.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
