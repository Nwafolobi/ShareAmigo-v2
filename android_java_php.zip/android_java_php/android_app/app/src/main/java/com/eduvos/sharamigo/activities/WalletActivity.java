package com.eduvos.sharamigo.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.eduvos.sharamigo.R;
import com.eduvos.sharamigo.models.Transaction;
import com.eduvos.sharamigo.network.ApiClient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WalletActivity extends AppCompatActivity {

    private TextView tvWalletTotalCredits, tvWalletAvailable, tvWalletEscrow;
    private LinearLayout layoutLedgerEntries;
    private int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        currentUserId = getIntent().getIntExtra("USER_ID", 2);

        tvWalletTotalCredits = findViewById(R.id.tvWalletTotalCredits);
        tvWalletAvailable = findViewById(R.id.tvWalletAvailable);
        tvWalletEscrow = findViewById(R.id.tvWalletEscrow);
        layoutLedgerEntries = findViewById(R.id.layoutLedgerEntries);

        loadWalletData();
    }

    private void loadWalletData() {
        ApiClient.getService().getLedger(currentUserId).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();
                    double balance = (double) data.get("credit_balance");
                    double escrow = (double) data.get("escrow_held");

                    tvWalletTotalCredits.setText(((int) (balance + escrow)) + " AmigoCredits");
                    tvWalletAvailable.setText(((int) balance) + " Pts");
                    tvWalletEscrow.setText(((int) escrow) + " Pts");

                    Gson gson = new Gson();
                    String json = gson.toJson(data.get("transactions"));
                    List<Transaction> txns = gson.fromJson(json, new TypeToken<List<Transaction>>(){}.getType());

                    renderLedgerRows(txns);
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                // Offline demo fallback
                tvWalletTotalCredits.setText("40 AmigoCredits");
                tvWalletAvailable.setText("25 Pts");
                tvWalletEscrow.setText("15 Pts");
            }
        });
    }

    private void renderLedgerRows(List<Transaction> txns) {
        layoutLedgerEntries.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        if (txns == null || txns.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("No transaction history recorded yet.");
            tvEmpty.setTextColor(getResources().getColor(R.color.grey_medium));
            layoutLedgerEntries.addView(tvEmpty);
            return;
        }

        for (Transaction t : txns) {
            View view = inflater.inflate(android.R.layout.simple_list_item_2, layoutLedgerEntries, false);
            TextView text1 = view.findViewById(android.R.id.text1);
            TextView text2 = view.findViewById(android.R.id.text2);

            boolean isDonor = t.getDonorId() == currentUserId;
            text1.setText(t.getItemTitle() + " (" + (isDonor ? "+" : "-") + t.getCreditAmount() + " Pts)");
            text1.setTextSize(14);
            text1.setTextColor(getResources().getColor(R.color.black));

            text2.setText((isDonor ? "Traded to: " + t.getReceiverName() : "Claimed from: " + t.getDonorName()) + " • " + t.getStatus());
            text2.setTextColor(getResources().getColor(R.color.grey_medium));

            layoutLedgerEntries.addView(view);
        }
    }
}
